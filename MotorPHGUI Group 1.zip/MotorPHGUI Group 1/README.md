# MotorPHGUI2
Updated Version of MotorPGUI using frames classes.
